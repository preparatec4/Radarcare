from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import requests
from bs4 import BeautifulSoup
import re
import time
import random

app = Flask(__name__)
CORS(app)

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'Accept-Language': 'pt-BR,pt;q=0.9',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
}

def extrair_telefone(texto):
    if not texto:
        return None
    texto = texto.replace('\xa0', ' ')
    padroes = [
        r'\(?\d{2}\)?\s?9\d{4}[-\s]?\d{4}',
        r'\(?\d{2}\)?\s?\d{4}[-\s]?\d{4}',
        r'(?<!\d)\d{11}(?!\d)',
        r'(?<!\d)\d{10}(?!\d)',
    ]
    for p in padroes:
        m = re.search(p, texto)
        if m:
            tel = re.sub(r'\D', '', m.group())
            if len(tel) >= 10:
                return tel
    return None

def formatar_tel(tel):
    if not tel:
        return None
    n = re.sub(r'\D', '', tel)
    if not n.startswith('55'):
        n = '55' + n
    return n

def buscar_olx(cidade, servico):
    resultados = []
    try:
        query = servico.replace(' ', '+')
        url = f'https://www.olx.com.br/brasil?q={query}&sf=1&o=1'
        resp = requests.get(url, headers=HEADERS, timeout=10)
        soup = BeautifulSoup(resp.text, 'html.parser')

        cards = soup.select('li[data-ds-component="DS-AdCard"]') or \
                soup.select('li.sc-1fcmfeb-2') or \
                soup.select('[data-lurker-detail="result_card"]')

        for card in cards[:15]:
            try:
                titulo_el = card.select_one('h2, h3, [class*="title"]')
                titulo = titulo_el.get_text(strip=True) if titulo_el else ''
                if not titulo:
                    continue

                desc_el = card.select_one('[class*="description"], p')
                desc = desc_el.get_text(strip=True) if desc_el else ''

                link_el = card.select_one('a[href]')
                link = link_el['href'] if link_el else ''
                if link and not link.startswith('http'):
                    link = 'https://www.olx.com.br' + link

                local_el = card.select_one('[class*="location"], [class*="city"]')
                local = local_el.get_text(strip=True) if local_el else cidade

                # Filtra só quem PROCURA (não quem oferece)
                texto_lower = (titulo + ' ' + desc).lower()
                palavras_procura = ['preciso', 'procuro', 'busco', 'quero contratar', 'minha mãe', 'meu pai', 'minha avó', 'meu avô', 'idoso', 'idosa', 'internado', 'familiar']
                palavras_oferta = ['ofereço', 'ofereço serviço', 'anos de experiência', 'procuro emprego', 'procuro vaga', 'disponível para trabalhar', 'clt', 'pj']
                
                eh_oferta = any(p in texto_lower for p in palavras_oferta)
                eh_procura = any(p in texto_lower for p in palavras_procura)
                
                if eh_oferta and not eh_procura:
                    continue

                tel = extrair_telefone(titulo + ' ' + desc)
                urgente = any(p in texto_lower for p in ['urgente', 'urgência', 'hoje', 'agora', 'hospital', 'internado', 'pronto socorro'])

                resultados.append({
                    'titulo': titulo,
                    'descricao': desc,
                    'local': local,
                    'fonte': 'olx',
                    'fonteLabel': 'OLX',
                    'link': link,
                    'telefone': tel,
                    'telefoneWa': formatar_tel(tel),
                    'urgente': urgente,
                })
            except:
                continue

        time.sleep(random.uniform(0.5, 1.2))
    except Exception as e:
        print(f'Erro OLX: {e}')
    return resultados

def buscar_getninjas(servico):
    resultados = []
    try:
        slugs = {
            'cuidador de idosos': 'cuidador-de-idosos',
            'acompanhante hospitalar': 'acompanhante-hospitalar',
            'enfermagem domiciliar': 'enfermeiro-domiciliar',
            'cuidador pos-cirurgia': 'cuidador-de-idosos',
            'cuidador alzheimer': 'cuidador-de-idosos',
            'home care': 'cuidador-de-idosos',
        }
        slug = slugs.get(servico, 'cuidador-de-idosos')
        url = f'https://www.getninjas.com.br/{slug}'
        resp = requests.get(url, headers=HEADERS, timeout=10)
        soup = BeautifulSoup(resp.text, 'html.parser')

        cards = soup.select('[class*="opportunity"], [class*="request"], article, .card')

        for card in cards[:15]:
            try:
                titulo_el = card.select_one('h2, h3, h4, [class*="title"]')
                titulo = titulo_el.get_text(strip=True) if titulo_el else ''
                if not titulo or len(titulo) < 10:
                    continue

                desc_el = card.select_one('[class*="description"], [class*="detail"], p')
                desc = desc_el.get_text(strip=True) if desc_el else ''

                link_el = card.select_one('a[href]')
                link = link_el['href'] if link_el else url
                if link and not link.startswith('http'):
                    link = 'https://www.getninjas.com.br' + link

                local_el = card.select_one('[class*="location"], [class*="city"], [class*="address"]')
                local = local_el.get_text(strip=True) if local_el else 'Ver anúncio'

                texto_lower = (titulo + ' ' + desc).lower()
                tel = extrair_telefone(titulo + ' ' + desc)
                urgente = any(p in texto_lower for p in ['urgente', 'hoje', 'agora', 'hospital'])

                resultados.append({
                    'titulo': titulo,
                    'descricao': desc,
                    'local': local,
                    'fonte': 'getninjas',
                    'fonteLabel': 'GetNinjas',
                    'link': link,
                    'telefone': tel,
                    'telefoneWa': formatar_tel(tel),
                    'urgente': urgente,
                })
            except:
                continue

        time.sleep(random.uniform(0.5, 1.0))
    except Exception as e:
        print(f'Erro GetNinjas: {e}')
    return resultados

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/buscar')
def buscar():
    cidade = request.args.get('cidade', '').strip()
    servico = request.args.get('servico', 'cuidador de idosos').strip()

    if not cidade:
        return jsonify({'erro': 'Informe a cidade', 'resultados': []})

    resultados = []

    olx = buscar_olx(cidade, servico)
    resultados.extend(olx)

    ninjas = buscar_getninjas(servico)
    # Filtra getninjas pela cidade
    cidade_lower = cidade.lower()
    for r in ninjas:
        if cidade_lower in r['local'].lower() or not r['local'] or r['local'] == 'Ver anúncio':
            resultados.append(r)

    # Facebook link
    fb_url = f"https://www.facebook.com/search/posts?q={requests.utils.quote('preciso ' + servico + ' ' + cidade)}"
    
    # Ordena urgentes primeiro
    resultados.sort(key=lambda x: (0 if x['urgente'] else 1))

    return jsonify({
        'resultados': resultados,
        'total': len(resultados),
        'facebook_url': fb_url,
        'cidade': cidade,
        'servico': servico,
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
