# RadarCare

Radar de leads para cuidadores de idosos. Busca clientes reais no OLX e GetNinjas.

## Deploy no Railway

1. Faça upload deste repositório no GitHub
2. Acesse railway.app e conecte o repositório
3. O sistema sobe automaticamente

## Uso local

```bash
pip install -r requirements.txt
python main.py
```
